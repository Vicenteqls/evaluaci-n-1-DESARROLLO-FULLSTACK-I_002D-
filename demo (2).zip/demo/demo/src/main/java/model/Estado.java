package model;

public class Estado {
    public enum Estado {
        PENDIENTE,
        EN_PREPARACION,
        EN_CAMINO,
        ENTREGADO,
        CANCELADO
    }

}