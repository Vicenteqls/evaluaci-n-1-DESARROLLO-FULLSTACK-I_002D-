package model;

import java.time.LocalDate;

public class Pedido {
    private Long id;
    private String nombreCliente;
    private String descripcion;
    private Estado estado;         // usa el enum Estado
    private TipoPedido tipoPedido; // usa el enum TipoPedido
    private Double montoTotal;
    private LocalDate fechaPedido;
}
