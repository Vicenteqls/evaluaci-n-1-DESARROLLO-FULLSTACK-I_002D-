package Repository;

public class IncidenciaRepository {
}
