package com.QuickOrder.QuickOrder.Model;

public enum TipoPedido {
    delivery,
    retiro_en_tienda,
    express
}
