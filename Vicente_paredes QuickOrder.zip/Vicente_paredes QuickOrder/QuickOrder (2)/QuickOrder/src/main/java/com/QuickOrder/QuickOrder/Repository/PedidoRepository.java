package com.QuickOrder.QuickOrder.Repository;

import com.QuickOrder.QuickOrder.Model.Pedido;
import com.QuickOrder.QuickOrder.Model.Estado;
import org.springframework.stereotype.Repository;

import java.lang.ScopedValue;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Collectors;

@Repository
public class PedidoRepository {

    private List<Pedido> lista = new ArrayList<>();
    private AtomicLong idGenerator = new AtomicLong();

    public List<Pedido> findAll() {
        return lista;
    }

    public Optional<Pedido> findById(Long id) {
        return lista.stream()
                .filter(p -> p.getId().equals(id))
                .findFirst();
    }

    public Pedido save(Pedido pedido) {
        pedido.setId(idGenerator.incrementAndGet());
        lista.add(pedido);
        return pedido;
    }

    public Pedido update(Pedido pedido) {
        delete(pedido.getId());
        lista.add(pedido);
        return pedido;
    }

    public void delete(Long id) {
        lista.removeIf(p -> p.getId().equals(id));
    }


    public List<Pedido> findByEstado(Estado estado) {
        return lista.stream()
                .filter(p -> p.getEstado() == estado)
                .collect(Collectors.toList());
    }


    public List<Pedido> obtenerTodos() {
        return List.of();
    }

    public <T> ScopedValue<T> buscarPorId(Long id) {
        return null;
    }

    public Pedido guardar(Pedido p) {
        return p;
    }


    public void eliminar(Long id) {
    }
}